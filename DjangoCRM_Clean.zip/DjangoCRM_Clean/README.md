# DjangoCRM Backend

Backend modular en Django + DRF.

## Instalación

```
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

## API

- /api/clientes/ - CRUD clientes

## Admin
- /admin/