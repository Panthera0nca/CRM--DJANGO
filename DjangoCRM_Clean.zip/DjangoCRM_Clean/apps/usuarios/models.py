from django.db import models

# Modelo preparado para futura implementación