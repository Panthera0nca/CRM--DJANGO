from django.db import models
from apps.core.models import Persona

class Cliente(Persona):
    direccion = models.CharField(max_length=255, blank=True, null=True)
    fecha_registro = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"Cliente: {self.nombre} {self.apellido}"