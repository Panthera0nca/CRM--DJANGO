from django.contrib import admin
from .models import Cliente  # Importar el modelo

admin.site.register(Cliente)  # Registrar el modelo para que aparezca en el admin
